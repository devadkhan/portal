jQuery(document).ready(function($) {
  /*
  setInterval(function() {
    $("#ctools-export-ui-list-items-reload").click();
  }, 1000);
  */
});
